<?php
	class DatabaseConnection {

		const DB_USER = 'paveen';
		const DB_PASSWORD = 'paveen@12345';
		const DB_HOST = 'localhost';
		const DB_NAME = 'NEWBOOKSTORE';

		private $dbc;

		function __construct() {
			$this->dbc = @mysqli_connect(
				self::DB_HOST,
				self::DB_USER,
				self::DB_PASSWORD,
				self::DB_NAME
			)
			OR die(
				'Could not connect to MySQL: ' . mysqli_connect_error()
			);

			mysqli_set_charset($this->dbc, 'utf8');
		}

		function prepare_string($string) {
			$string = strip_tags($string);
			$string = mysqli_real_escape_string($this->dbc, trim($string));
			return $string;
		}

		function get_dbc() {
			return $this->dbc;
		}
        
        function register_user($name, $email, $password){
            
            $name_clean = $this->prepare_string($name);
            $email_clean = $this->prepare_string($email);
            $password_clean = $this->prepare_string($password);

            $query = "INSERT INTO users(UserName , email, password) VALUES (?,?,?)";
        
            $stmt = mysqli_prepare($this->dbc, $query);

            mysqli_stmt_bind_param(
                $stmt,
                'sss',
                $name_clean,
                $email_clean,
                $password_clean,
            );

            $result = mysqli_stmt_execute($stmt);

            return $result;
        }

        function insertorder($BookID, $USERID, $Quantity){
            

            $query = "INSERT INTO BookOrders(BookID, USERID, Quantity, OrderPlacedDate) VALUES (?,?,?,'2022-08-18')";
        
            $stmt = mysqli_prepare($this->dbc, $query);

            mysqli_stmt_bind_param(
                $stmt,
                'iii',
                $BookID,
                $USERID,
                $Quantity
            );

            $result = mysqli_stmt_execute($stmt);

            return $result;
        }


        function get_users() {
            $query = 'SELECT * FROM users;';
            $result = @mysqli_query($this->dbc,$query);
            return $result;
        }

        function get_products() {
            $query = 'SELECT B.*, P.PublicationName FROM BookInventory B INNER JOIN PublicationMaster P on P.PublicationID = B.PublicationID;';
            $results = @mysqli_query($this->dbc,$query);
            return $results;
        }

        function get_productsByPublication($Publication) {
            $Publicationclean = $this->prepare_string($Publication);
            $query = 'SELECT B.*, P.PublicationName FROM BookInventory B INNER JOIN PublicationMaster P on P.PublicationID = B.PublicationID WHERE P.PublicationID = ?;';
            $stmt = mysqli_prepare($this->dbc, $query);
            mysqli_stmt_bind_param(
                $stmt,
                's',
                $Publicationclean
            );
            
            mysqli_stmt_execute($stmt);
            $results = mysqli_stmt_get_result($stmt);
            return $results;
        }

        function get_productsByBookId($bookid) {
            $bookidclean = $this->prepare_string($bookid);
            $query = 'SELECT B.*, P.PublicationName FROM BookInventory B INNER JOIN PublicationMaster P on P.PublicationID = B.PublicationID WHERE B.BookID = ?;';
            $stmt = mysqli_prepare($this->dbc, $query);
            mysqli_stmt_bind_param(
                $stmt,
                's',
                $bookidclean
            );
            mysqli_stmt_execute($stmt);
            $results = mysqli_stmt_get_result($stmt);
            return $results;
        }
        
        function get_user_by_id($user_id) {
            $user_id_clean = $this->prepare_string($user_id);
            $query = "SELECT * FROM users WHERE user_id = ?;";
            $stmt = mysqli_prepare($this->dbc, $query);
            mysqli_stmt_bind_param(
                $stmt,
                's',
                $user_id_clean
            );
            
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            return $result;
        }

        function get_user_by_emailpassword($email, $password) {
            $email_clean = $this->prepare_string($email);
            $password_clean = $this->prepare_string($password);
            $query = "SELECT * FROM users WHERE email = ? and password = ?;";
            $stmt = mysqli_prepare($this->dbc, $query);
            mysqli_stmt_bind_param(
                $stmt,
                'ss',
                $email_clean,
                $password_clean
            );
            
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            return $result;
        }
        
        function update_user($user_id, $name, $email, $phone, $province){
            
            $user_id_clean = $this->prepare_string($user_id);
            $name_clean = $this->prepare_string($name);
            $email_clean = $this->prepare_string($email);
            $phone_clean = $this->prepare_string($phone);
            $province_clean = $this->prepare_string($province);

            $query = "UPDATE users SET name = ?, email = ?, phone = ?, province = ? WHERE  user_id = ?;";

            $stmt = mysqli_prepare($this->dbc, $query);

            mysqli_stmt_bind_param(
                $stmt,
                'sssss',
                $name_clean,
                $email_clean,
                $phone_clean,
                $province_clean,
                $user_id_clean
            );

            $result = mysqli_stmt_execute($stmt);
            return $result;
        }
        
        function delete_user_by_id($user_id) {
            
            $user_id_clean = $this->prepare_string($user_id);
            $query = "DELETE FROM Users WHERE user_id = ? ;";
            $stmt = mysqli_prepare($this->dbc, $query);
            mysqli_stmt_bind_param(
                $stmt,
                's',
                $user_id_clean
            );
            
            $result = mysqli_stmt_execute($stmt);

            return $result;
        }
	}
?>