<?php # Script 9.2 - mysqli_connect.php



// Make the connection:
$dbc = @mysqli_connect('localhost', '', '', 'BOOKSTORE') OR die('Could not connect to MySQL: ' . mysqli_connect_error() );

// Set the encoding...
mysqli_set_charset($dbc, 'utf8');