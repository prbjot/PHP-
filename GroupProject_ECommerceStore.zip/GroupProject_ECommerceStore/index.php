<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store</title>
    <link rel="stylesheet" href="./css/normalize-and-boilerplate.css" />
    <link rel="stylesheet" href="./css/font-awesome.css" />
    <link rel="stylesheet" href="./css/style.css" />
</head>

<body>
    <header class="header">
        <div class="row max-inner">
            <div class="columns col-2">
                <a href="index.php" title="Jewelry" class="logo">Book Store</a>
            </div>

            <div class="columns col-6">
                <a href="#" class="toggle-nav">
                    <i class="fa fa-bars"></i> Menu
                </a>
                <nav class="main-nav">
                    <ul>
                        <li><a href="products.php">Collection</a></li>
                        <li><a href="index.php">CHECKOUT </a></li>
                        <li><a href="#">About</a></li>
                    </ul>
                </nav>
            </div>

            <div class="columns col-4">
                <ul class="header-controls">
                    <li class="header-search">
                        <a href="login.php" class="reveal-search">
                            <i class="fa fa-user"></i> Login
                        </a>
                        <div class="search-wrapper">
                            <form class="search-form">
                                <input placeholder="Search..." type="text">
                            </form>
                        </div>
                    </li>
                    <li class="header-cart">
                        <a href="checkvalidcart.php" title="view cart">
                            <span class="fa fa-shopping-cart"></span>
                            <span class="cart-count">Go to Cart</span>
                        </a>
                    </li>
                    <li class="header-actions">
                        <a href="register.php" title="Log out"><span class="fa fa-user"></span> Register</a>
                    </li>
                </ul>
            </div>

        </div>
    </header>
     <!-- start: product grid -->
     <section class="product-grid">

<header class="row section-header max-inner">
  <div class="columns-12 col-centered">
    <h2>Featured Products</h2><hr />
  </div>
</header>

<div class="row max-inner">

  <!-- start: grid item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="product.html"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a class="grid-item-link" href="product.html">
          <span class="grid-item-meta">Lorem ipsum</span><hr />
          <span class="grid-item-title">consectetur adipisicing elit</span>
          <span class="grid-item-price">$220.00</span>
        </a>
      </h2>
    </div>
  </div>
  <!-- end: grid item -->
  <!-- start: grid item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="product.html"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">Dolor sit</span><hr />
          <span class="grid-item-title">Dolore magna aliqua</span>
          <span class="grid-item-price">$187.00</span>
        </a>
      </h2>
    </div>
  </div>
  <!-- end: grid item -->
  <!-- start: grid item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="product.html"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">Duis aute irure</span><hr />
          <span class="grid-item-title">Dolor in reprehenderit</span>
          <span class="grid-item-price">$380.00</span>
        </a>
      </h2>
    </div>
  </div>
  <!-- end: grid item -->
  <!-- start: grid item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="product.html"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">Enim ad minim </span><hr />
          <span class="grid-item-title"> Nemo enim ipsam</span>
          <span class="grid-item-price">$130.00</span>
        </a>
      </h2>
    </div>
  </div>
  <!-- end: grid item -->

</div>
</section>
<!-- end: product grid -->

<!-- start: collections grid -->
<section class="collections-section">

<div class="row max-inner">

  <div class="columns col-6 collection-item">
    <a href="shop.html">
      <img src="images/bookwrapper.jpeg">
      <div class="collection-desc">
        <h2>With love and passion</h2>
        <h3>New shoe collection</h3>
      </div>
    </a>
  </div>
    
  <div class="columns col-6 collection-item">
    <a href="shop.html">
      <img src="images/bookwrapper.jpeg">
      <div class="collection-desc">
        <h2>Paris inspiration</h2>
        <h3>For a good time</h3>
      </div>
    </a>
  </div>

</div>

<div class="row max-inner">
  <div class="columns col-12 collection-item">
    <a href="shop.html">
      <img src="images/bookwrapper.jpeg">
      <div class="collection-desc">
        <h2>Fashion clothes</h2>
        <h3>For summer</h3>
      </div>
    </a>
  </div>
</div>

</section>
<!-- end: collections grid -->


<!-- start: blog section -->
<section class="blog-section">

<header class="row section-header max-inner">
  <div class="columns-12 col-centered">
    <h2>Blog news</h2><hr />
  </div>
</header>

<div class="row max-inner">

  <!-- start: blog item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="#"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">30 May 2014</span>
          <span class="grid-item-title">Dolor in reprehenderit</span>
        </a>
      </h2>
      <p>Natus error sit voluptatem accusantium doloremque laudantium totam rem...</p>
    </div>
  </div>
  <!-- end: blog item -->

  <!-- start: blog item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="#"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">27 May 2014</span>
          <span class="grid-item-title">Accusantium doloremque</span>
        </a>
      </h2>
      <p>Natus error sit voluptatem accusantium doloremque laudantium totam rem...</p>
    </div>
  </div>
  <!-- end: blog item -->

  <!-- start: blog item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="#"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">24 May 2014</span>
          <span class="grid-item-title">Totam rem aperiam</span>
        </a>
      </h2>
      <p>Natus error sit voluptatem accusantium doloremque laudantium totam rem...</p>
    </div>
  </div>
  <!-- end: blog item -->

  <!-- start: blog item -->
  <div class="columns col-3 grid-item">
    <div class="grid-item-media"><a href="#"><img src="images/bookwrapper.jpeg" /></a></div>
    <div class="grid-item-desc">
      <h2>
        <a href="product.html">
          <span class="grid-item-meta">21 May 2014</span>
          <span class="grid-item-title">Nemo enim ipsam voluptatem</span>
        </a>
      </h2>
      <p>Natus error sit voluptatem accusantium doloremque laudantium totam rem...</p>
    </div>
  </div>
  <!-- end: blog item -->

</div>

</section>
<!-- end: blog section -->

    <footer class="footer">
        <div class="row max-inner">

            <div class="columns col-2">
                <h3>Address</h3>
                <p>
                    Book Store LLC<br />
                    <br />
                    299 Doon Valley Drive<br />
                    Kitchener, Ontario N2G 4M4, Canada<br />
                    <br />
                    <a href="#">contact@bookstore.ca</a><br />
                    Phone: 519-748-5000
                </p>
            </div>

            <div class="columns col-2">
                <h3>Customer Service</h3>
                <ul>
                    <li><a href="#">About us</a></li>
                    <li><a href="#">Money back guarantee</a></li>
                    <li><a href="#">Help center</a></li>
                    <li><a href="#">Delivery</a></li>
                    <li><a href="#">Payment</a></li>
                </ul>
            </div>

            <div class="columns col-2">
                <h3>Account</h3>
                <ul>
                    <li><a href="#">Login</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>

            <div class="columns col-6">
                <h3>Follow us</h3>
                <div class="row">
                    <form class="newsletter-form">
                        <div class="columns col-8">
                            <input placeholder="Enter your Email ..." type="text">
                        </div>
                        <div class="columns col-4">
                            <input type="submit" value="Subscribe" class="submit">
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="columns col-12 social-links">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-google-plus"></i></a>
                        <a href="#"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </footer>
    <!-- end: footer -->


    <!-- start: copyright -->
    <section class="footer-copyright">
        <div class="row max-inner">
            <div class="columns col-7 col-centered">
                <p>Copyright 2022 Book Store. All rights reserved.</p>
            </div>
        </div>
    </section>
    <!-- end: copyright -->
</body>

</html>