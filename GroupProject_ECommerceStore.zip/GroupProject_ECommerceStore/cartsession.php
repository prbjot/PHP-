<?php
require('sqlconnection.php');
require('cart.php');


$error = null;
if (!empty($_GET['bookid'])) {
    $bookid = $_GET['bookid'];
} else {
    $bookid = null;
    $error = "<p> Error! Book ID not found.";
}

if ($error == null) {
    $connection = new DatabaseConnection();
    $result = $connection->get_productsByBookId($bookid);
    
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        echo $row['BookName'];

        session_start();
        if (empty($_SESSION["cartData"])) {
            $_SESSION["cartData"] = $row["BookName"] .',' . $row["AuthorName"] . ','. $row["PublishedDate"] . ','. $row["PublicationName"] . ',1,20,'. $row["BookID"];
            echo '<h1> Book Added To Cart Successfully !!!!';
        } else {
            $newProduect = $row["BookName"] .',' . $row["AuthorName"] . ','. $row["PublishedDate"] . ','. $row["PublicationName"] . ',1,20,'. $row["BookID"];
            $_SESSION["cartData"] = $_SESSION["cartData"] .'$'. $newProduect;
            echo '<h1> Book Added To Cart Successfully !!!!';
        }
    }
} else {
    echo $error;
}
function checkIsPresent($existingCartArray,  $bookid)
{
    foreach ($existingCartArray as $existProduct) {
        echo $existingCartArray[$existProduct->bookid];
        if ($bookid == $existProduct->bookid) {
            return true;
        }
    }
    return false;
}
?>
