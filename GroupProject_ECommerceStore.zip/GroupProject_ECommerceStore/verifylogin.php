<?php
require('sqlconnection.php');
$errors = [];

if (!empty($_POST['email'])) {
    $email = $_POST['email'];
} else {
    $email = null;
    $errors[] = "<p> Error!!!! Email is required!!</p>";
}

if (!empty($_POST['password'])) {
    $password = $_POST['password'];
} else {
    $password = null;
    $errors[] = "<p> Error!!!! Password is required!!</p>";
}

if (count($errors) == 0) {
    $connection = new DatabaseConnection();
    $results = $connection->get_user_by_emailpassword($email, $password);
    if (mysqli_num_rows($results) == 1) {
        session_start();
        $_SESSION["login"] = true;
        while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC)) { 
            $_SESSION["username"] = $row['UserName'];
            $_SESSION["email"] =  $row['email'];
            $_SESSION["userid"] =  $row['USERID'];
        }
        header("Location: checkout.php");
    } else {
        echo "<h5>Invalid Login Credentials !!!!</h5>";
    }
} else {
    foreach ($errors as $error) {
        echo $error;
    }
}
