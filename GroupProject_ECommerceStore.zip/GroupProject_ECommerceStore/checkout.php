<?php
session_start();
if ($_SESSION["login"] == true && isset($_SESSION["cartData"])) {
    // $name = $_SESSION["name"];
    // $authorname = $_SESSION["authorname"];
    // $publicationname = $_SESSION["publicationname"];
    // $publishdate = $_SESSION["publishdate"];
    // $quantity = $_SESSION["quantity"];
} else {
    header("Location: products.php");
}
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store</title>
    <link rel="stylesheet" href="./css/normalize-and-boilerplate.css" />
    <link rel="stylesheet" href="./css/font-awesome.css" />
    <link rel="stylesheet" href="./css/style.css" />
</head>

<body>
    <header class="header">
        <div class="row max-inner">
            <div class="columns col-2">
                <a href="index.php" title="Jewelry" class="logo">Book Store</a>
            </div>

            <div class="columns col-6">
                <a href="#" class="toggle-nav">
                    <i class="fa fa-bars"></i> Menu
                </a>
                <nav class="main-nav">
                    <ul>
                        <li><a href="products.php">Collection</a></li>
                        <li><a href="index.php">CHECKOUT </a></li>
                        <li><a href="#">About</a></li>
                    </ul>
                </nav>
            </div>

            <div class="columns col-4">
                <ul class="header-controls">
                    <li class="header-search">
                        <a href="login.php" class="reveal-search">
                            <i class="fa fa-user"></i> Login
                        </a>
                        <div class="search-wrapper">
                            <form class="search-form">
                                <input placeholder="Search..." type="text">
                            </form>
                        </div>
                    </li>
                    <li class="header-cart">
                        <a href="checkvalidcart.php" title="view cart">
                            <span class="fa fa-shopping-cart"></span>
                            <span class="cart-count">Go to Cart</span>
                        </a>
                    </li>
                    <li class="header-actions">
                        <a href="register.php" title="Log out"><span class="fa fa-user"></span> Register</a>
                    </li>
                </ul>
            </div>

        </div>
    </header>
    <div class="checkoutWrapper">
        <h2 style="text-align: center;margin: 40px 0;">Check Out</h2>
        <table width="100%" class="newTable">
            <thead>
                <tr>
                    <th>Book Title</th>
                    <th>Author Name</th>
                    <th>Published Date</th>
                    <th>Publication Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>BookID</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sr_no = 0;
                $row = explode("$", $_SESSION["cartData"]);
                $str_to_print = "";
                foreach ($row as $details) {
                    $briefDetails = explode(",", $details);
                    $str_to_print .= "<tr>";
                    foreach ($briefDetails as $value) {
                        $str_to_print .= "<td>$value</td>";
                    }
                    $str_to_print .= "</tr>";
                }
                echo $str_to_print;
                // while (count($row) <= 1) {
                //     echo $row;
                //     // $productDetails = explode(",", $row);
                //     $sr_no++;
                //     $str_to_print = "";
                //     $str_to_print = "<tr> <td>{explode()}</td>";
                //     $str_to_print .= "<td>$sr_no</td>";
                //     $str_to_print .= "<td> {$row['name']}</td>";
                //     $str_to_print .= "<td> {$row['email']}</td>";
                //     $str_to_print .= "<td> {$row['phone']}</td>";
                //     $str_to_print .= "<td> {$row['province']}</td>";
                //     $str_to_print .= "<td> <a href='edit_user.php?user_id={$row['user_id']}'>Edit</a> | <a href='delete_user.php?user_id={$row['user_id']}'>Delete</a> </td> </tr>";

                //     echo $str_to_print;
                // }
                ?>
            </tbody>
        </table>
       
    </div>
    <div class="buttonwrapper">
            <a href="placeorder.php" class="btn">place Order</a>
            <a href="generatepdf.php" class="btn">Generate Invoice</a>
        </div>
    <footer class="footer">
        <div class="row max-inner">

            <div class="columns col-2">
                <h3>Address</h3>
                <p>
                    Book Store LLC<br />
                    <br />
                    299 Doon Valley Drive<br />
                    Kitchener, Ontario N2G 4M4, Canada<br />
                    <br />
                    <a href="#">contact@bookstore.ca</a><br />
                    Phone: 519-748-5000
                </p>
            </div>

            <div class="columns col-2">
                <h3>Customer Service</h3>
                <ul>
                    <li><a href="#">About us</a></li>
                    <li><a href="#">Money back guarantee</a></li>
                    <li><a href="#">Help center</a></li>
                    <li><a href="#">Delivery</a></li>
                    <li><a href="#">Payment</a></li>
                </ul>
            </div>

            <div class="columns col-2">
                <h3>Account</h3>
                <ul>
                    <li><a href="#">Login</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>

            <div class="columns col-6">
                <h3>Follow us</h3>
                <div class="row">
                    <form class="newsletter-form">
                        <div class="columns col-8">
                            <input placeholder="Enter your Email ..." type="text">
                        </div>
                        <div class="columns col-4">
                            <input type="submit" value="Subscribe" class="submit">
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="columns col-12 social-links">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-google-plus"></i></a>
                        <a href="#"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </footer>
    <!-- end: footer -->


    <!-- start: copyright -->
    <section class="footer-copyright">
        <div class="row max-inner">
            <div class="columns col-7 col-centered">
                <p>Copyright 2022 Book Store. All rights reserved.</p>
            </div>
        </div>
    </section>
    <!-- end: copyright -->
</body>

</html>