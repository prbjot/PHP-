<?php
    require('sqlconnection.php');
    $errors = [];

    if(!empty($_POST['username'])){
        $username = $_POST['username'];  
    } else {
        $username = null;
        $errors[] = "<p> Error!!!! UserName is required!!</p>";
    }
    if(!empty($_POST['email'])){
        $email = $_POST['email'];  
    } else {
        $email = null;
        $errors[] = "<p>Error !!! Email is required!!</p>";
    }
    if(!empty($_POST['password'])){
        $password = $_POST['password'];  
    } else {
        $password = null;
        $errors[] = "<p> Error !!!! Password is required!!</p>";
    }
   
    if(count($errors) == 0){
        
        $connection = new DatabaseConnection();
        
        $result = $connection->register_user($username, $email, $password);
        
        if($result){
            header("Location: login.php");
            exit;
        } else {
            echo "</h3>Some error in Saving the data</h3>";
        }
        
    } else {
        foreach($errors as $error){
            echo $error;
        }
    }
?>



























