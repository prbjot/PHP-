<?php
require('sqlconnection.php');
$connection = new DatabaseConnection();

session_start();
$row = explode("$", $_SESSION["cartData"]);
foreach ($row as $details) {
    $briefDetails = explode(",", $details);
    $results = $connection->insertorder((int)$briefDetails[6], (int)$_SESSION["userid"], (int)$briefDetails[4]);
    
}
echo "<h2>Order Placed Successfully !!!!</h2>";
?>
