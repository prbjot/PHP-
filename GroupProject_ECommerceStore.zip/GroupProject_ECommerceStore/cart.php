<?php
class Product
{
    public $bookid;
    public $name;
    public $authorname;
    public $publishdate;
    public $quantity;
    public $publication;
}
?>