<?php
   session_start();
   if (count(array($_SESSION["cartData"])) > 1) { 
    echo "<h1>No Product Found In Cart !!!</h1>";
   } else if (isset($_SESSION["login"]) === false) {
    echo "<h1>Pleas login to proceed !!!</h1>";
   } else {
    header("Location: checkout.php");
   }
?>