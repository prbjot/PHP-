<?php
require('sqlconnection.php');
$connection = new DatabaseConnection();
if (!empty($_POST['Publication'])) {
    $results = $connection->get_productsByPublication($_POST['Publication']);
} else {
    $results = $connection->get_products();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store</title>
    <link rel="stylesheet" href="./css/normalize-and-boilerplate.css" />
    <link rel="stylesheet" href="./css/font-awesome.css" />
    <link rel="stylesheet" href="./css/style.css" />
</head>

<body>
    <header class="header">
        <div class="row max-inner">
            <div class="columns col-2">
                <a href="index.php" title="Jewelry" class="logo">Book Store</a>
            </div>

            <div class="columns col-6">
                <a href="#" class="toggle-nav">
                    <i class="fa fa-bars"></i> Menu
                </a>
                <nav class="main-nav">
                    <ul>
                        <li><a href="products.php">Collection</a></li>
                        <li><a href="index.php">CHECKOUT </a></li>
                        <li><a href="#">About</a></li>
                    </ul>
                </nav>
            </div>

            <div class="columns col-4">
                <ul class="header-controls">
                    <li class="header-search">
                        <a href="login.php" class="reveal-search">
                            <i class="fa fa-user"></i> Login
                        </a>
                        <div class="search-wrapper">
                            <form class="search-form">
                                <input placeholder="Search..." type="text">
                            </form>
                        </div>
                    </li>
                    <li class="header-cart">
                        <a href="checkvalidcart.php" title="view cart">
                            <span class="fa fa-shopping-cart"></span>
                            <span class="cart-count">Go to Cart</span>
                        </a>
                    </li>
                    <li class="header-actions">
                        <a href="register.php" title="Log out"><span class="fa fa-user"></span> Register</a>
                    </li>
                </ul>
            </div>

        </div>
    </header>
    <!-- start: breadcrumbs -->
    <section class="row breadcrumbs max-inner">
        <div class="columns col-12">
            <ul class="breadcrumb-list">
                <li><a href="index.html">Home</a></li>
                <li>Product results</li>
            </ul>
        </div>
    </section>
    <!-- end: breadcrumbs -->
    <!-- start: sort + product nav -->
    <section class="filter-sort">
        <div class="row max-inner">





            <div class="columns col-6 products-paging">
                <ul>
                    <li><a href="#"><i class="fa fa-caret-left"></i></a></li>
                    <li><a href="#">1</a></li>
                    <li><a href="#" class="current-prod-page">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#"><i class="fa fa-caret-right"></i></a></li>
                </ul>
            </div>


        </div>
    </section>
    <!-- end: sort + product nav -->

    <section class="filterWrapper">
        <form class="form" action="products.php" method="post">
            <div class="form-group" style="margin-bottom: 10px;">
                <label class="Publication">Publication</label>
                <div class="select">
                    <select name="Publication" id="Publication">
                        <option value="">All Publications</option>
                        <option value="1">Grafton Books</option>
                        <option value="2">Modern Library Books</option>
                        <option value="3">Nimbus Publishing</option>
                    </select>
                    <span class="focus"></span>
                </div>
            </div>
            <input type="submit" class="submit" value="Search" />
    </section>

    <!-- start: product grid -->
    <section class="product-grid shop-grid">
        <div class="row max-inner sortable-grid">
            <!-- start: grid item -->
            <?php
            $sr_no = 0;
            while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC)) {
                $sr_no++;
                $str_to_print = "<div class='columns col-3 grid-item'>";
                $str_to_print .= "<div class='grid-item-media'><a href='#'><img src='./images/bookwrapper.jpeg' /></a></div>";
                $str_to_print .= "<div class='grid-item-desc'>";
                $str_to_print .= "<h2>";
                $str_to_print .= "<a class='grid-item-link' href='#'>";
                $str_to_print .= "<span class='grid-item-meta'>{$row['AuthorName']}</span>";
                $str_to_print .= "<hr />";
                $str_to_print .= "<span class='grid-item-title'>{$row['BookName']}</span>";
                $str_to_print .= "<span class='grid-item-description'>{$row['PublicationName']}</span>";
                $str_to_print .= "<span class='grid-item-price'>$ 100</span>";
                $str_to_print .= "<span class='grid-item-quantity'>{$row['Quantity']} left !</span>";
                $str_to_print .= "<a class='submit editButton' href='cartsession.php?bookid={$row['BookID']}'>ADD TO CART</a>";
                $str_to_print .= "</a>";
                $str_to_print .= "</h2>";
                $str_to_print .= "</div>";
                $str_to_print .= "</div>";
                echo $str_to_print;
            }
            ?>
            <!-- end: grid item -->
        </div>
    </section>
    <!-- end: product grid -->
    <footer class="footer">
        <div class="row max-inner">

            <div class="columns col-2">
                <h3>Address</h3>
                <p>
                    Book Store LLC<br />
                    <br />
                    299 Doon Valley Drive<br />
                    Kitchener, Ontario N2G 4M4, Canada<br />
                    <br />
                    <a href="#">contact@bookstore.ca</a><br />
                    Phone: 519-748-5000
                </p>
            </div>

            <div class="columns col-2">
                <h3>Customer Service</h3>
                <ul>
                    <li><a href="#">About us</a></li>
                    <li><a href="#">Money back guarantee</a></li>
                    <li><a href="#">Help center</a></li>
                    <li><a href="#">Delivery</a></li>
                    <li><a href="#">Payment</a></li>
                </ul>
            </div>

            <div class="columns col-2">
                <h3>Account</h3>
                <ul>
                    <li><a href="#">Login</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">My Account</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>

            <div class="columns col-6">
                <h3>Follow us</h3>
                <div class="row">
                    <form class="newsletter-form">
                        <div class="columns col-8">
                            <input placeholder="Enter your Email ..." type="text">
                        </div>
                        <div class="columns col-4">
                            <input type="submit" value="Subscribe" class="submit">
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="columns col-12 social-links">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-google-plus"></i></a>
                        <a href="#"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </footer>
    <!-- end: footer -->


    <!-- start: copyright -->
    <section class="footer-copyright">
        <div class="row max-inner">
            <div class="columns col-7 col-centered">
                <p>Copyright 2022 Book Store. All rights reserved.</p>
            </div>
        </div>
    </section>
    <!-- end: copyright -->

</body>

</html>