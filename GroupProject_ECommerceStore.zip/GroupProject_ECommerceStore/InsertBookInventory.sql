INSERT INTO `PublicationMaster` (`PublicationName`)VALUES ('Grafton Books');
INSERT INTO `PublicationMaster` (`PublicationName`)VALUES ('Modern Library Books');
INSERT INTO `PublicationMaster` (`PublicationName`)VALUES ('Nimbus Publishing');


INSERT INTO `BookInventory`(`BookName`, `AuthorName`, `PublicationID`, `PublishedDate`, `Quantity`) VALUES ('The Top 100 Crime Novels of All Time','David Pringle',1,'1990-01-02',100);			
INSERT INTO `BookInventory`(`BookName`, `AuthorName`, `PublicationID`, `PublishedDate`, `Quantity`) VALUES ('Modern Fantasy: The 100 Best Novels','David Pringle',2,'1988-01-02',300);		
INSERT INTO `BookInventory`(`BookName`, `AuthorName`, `PublicationID`, `PublishedDate`, `Quantity`) VALUES ('Le Mondes 100 Books of the Century','Le Monde',3,'1999-01-02', 200);			
INSERT INTO `BookInventory`(`BookName`, `AuthorName`, `PublicationID`, `PublishedDate`, `Quantity`) VALUES ('Modern Library 100 Best Nonfiction','Modern Library',1,'1998-01-02',340);		
INSERT INTO `BookInventory`(`BookName`, `AuthorName`, `PublicationID`, `PublishedDate`, `Quantity`) VALUES ('The Top 100 Mystery Novels of All Time','Mystery Writers of America',2,'1995-01-02',20);			
INSERT INTO `BookInventory`(`BookName`, `AuthorName`, `PublicationID`, `PublishedDate`, `Quantity`) VALUES ('Atlantic Canada 100 Greatest Books','Nimbus Publishing',2,'2008-01-02',80);	


